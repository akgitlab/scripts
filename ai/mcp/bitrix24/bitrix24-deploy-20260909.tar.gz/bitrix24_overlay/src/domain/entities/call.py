"""Доменная сущность: звонок Bitrix24 (телефония)."""

from dataclasses import dataclass
from typing import Any, ClassVar


@dataclass(frozen=True, slots=True)
class Call:
    """Звонок из статистики телефонии (voximplant.statistic.get).

    :param call_id: ID звонка
    :param phone_number: Номер телефона
    :param call_type: 1=исходящий, 2=входящий, 3=пропущенный исходящий, 4=пропущенный входящий
    :param duration: Длительность в секундах
    :param date: Дата/время звонка
    :param crm_entity: Привязка к CRM ('LEAD_123', 'DEAL_456', ...)
    :param user_id: ID пользователя-оператора
    :param record_url: URL записи разговора (если есть)
    """

    call_id: str
    phone_number: str
    call_type: int
    duration: int
    date: str
    crm_entity: str = ""
    user_id: int = 0
    record_url: str = ""

    CALL_TYPES: ClassVar[dict[int, str]] = {
        1: "исходящий",
        2: "входящий",
        3: "пропущенный исходящий",
        4: "пропущенный входящий",
    }

    @classmethod
    def from_api(cls, row: dict[str, Any]) -> "Call":
        return cls(
            call_id=str(row.get("ID") or row.get("CALL_ID") or ""),
            phone_number=row.get("PHONE_NUMBER", ""),
            call_type=int(row.get("CALL_TYPE") or 0),
            duration=int(row.get("CALL_DURATION") or 0),
            date=row.get("CALL_START_DATE", ""),
            crm_entity=row.get("CRM_ENTITY_TYPE", "") and
                       f"{row.get('CRM_ENTITY_TYPE')}_{row.get('CRM_ENTITY_ID')}",
            user_id=int(row.get("USER_ID") or 0),
            record_url=row.get("RECORD_FILE_ID", "") or "",
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "call_id": self.call_id,
            "phone_number": self.phone_number,
            "call_type": self.CALL_TYPES.get(self.call_type, str(self.call_type)),
            "duration_sec": self.duration,
            "date": self.date,
            "crm_entity": self.crm_entity,
            "user_id": self.user_id,
            "record_url": self.record_url,
        }

    def to_str_json(self) -> str:
        import json
        return json.dumps(self.to_dict(), ensure_ascii=False)
