# bitrix24_overlay — кастомные инструменты поверх bitrix24_mcp 1.0.1

Накладывается deploy-скриптом (`deploy-bitrix24-mcp.sh`) на девственные
исходники bitrix24_mcp 1.0.1 с PyPI после распаковки, до `uv sync`.

## Добавляет

**Чаты (scope im):**
- `list_dialogs` — недавние диалоги/беседы владельца вебхука
- `get_dialog_history` — реплики диалога (пагинация по 50)
- `create_chat` — создание беседы с участниками
- `send_message` — отправка сообщения
- `analyze_dialog` — сводка: участники, объём, кто сколько написал

**Телефония (scope telephony):**
- `list_calls` — история звонков (фильтры: user_id, call_type, даты)
- `calls_summary` — агрегат для воронки: вх/исх/пропущенные, средняя длительность

## Модель доступа im

Виден только чаты, где владелец вебхука (юзер 974 «Интеграция MCP»)
состоит или создал их. Добавляйте его в целевые беседы в UI B24.

## Структура overlay

```
src/
├── domain/entities/dialog.py            # Dialog, DialogMessage
├── domain/entities/call.py              # Call
├── application/services/dialog.py       # DialogService (+ analyze_dialog)
├── application/services/call.py         # CallService (+ calls_summary)
├── infrastructure/bitrix/
│   ├── bitrix_dialog_repository.py      # im.*
│   └── bitrix_call_repository.py        # voximplant.*
├── infrastructure/mcp/handlers/
│   ├── chat.py                          # register_chat_handlers
│   └── call.py                          # register_call_handlers
└── presentation/mcp.py                  # ЗАМЕНЯЕТ upstream (добавляет 2 регистра)
```

Все вызовы REST, методы: im.recent.get, im.dialog.messages.get, im.chat.add,
im.message.add, im.chat.get, im.user.get, voximplant.statistic.get.
