"""Репозиторий: статистика телефонии Bitrix24 (voximplant)."""

from typing import Any, ClassVar

from fast_bitrix24 import Bitrix

from src.domain.entities.call import Call
from src.infrastructure.logging.logger import logger


class BitrixCallRepository:
    """История звонков через voximplant.statistic.* — read-only."""

    _METHOD_STATISTIC: ClassVar[str] = "voximplant.statistic.get"

    def __init__(self, bitrix: Bitrix) -> None:
        self._bitrix = bitrix

    async def list_calls(
        self,
        limit: int = 50,
        user_id: int | None = None,
        call_type: int | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
    ) -> list[Call]:
        """Выборка звонков с фильтрами.

        :param limit: Максимум записей (постранично по 50)
        :param user_id: Фильтр по оператору
        :param call_type: 1=исходящий, 2=входящий, 3/4=пропущенные
        :param date_from: Дата начала (YYYY-MM-DD)
        :param date_to: Дата конца (YYYY-MM-DD)
        """
        result: list[Call] = []
        next_page: int = 0

        while len(result) < limit:
            params: dict[str, Any] = {
                "FILTER": {},
                "START": next_page,
            }
            if user_id:
                params["FILTER"]["USER_ID"] = user_id
            if call_type:
                params["FILTER"]["CALL_TYPE"] = call_type
            if date_from:
                params["FILTER"][">=CALL_START_DATE"] = date_from
            if date_to:
                params["FILTER"]["<=CALL_START_DATE"] = date_to + "T23:59:59"

            batch = await self._bitrix.call(self._METHOD_STATISTIC, params) or []
            if not batch:
                break

            result.extend(Call.from_api(row) for row in batch)

            if len(batch) < 50:
                break
            next_page += 50

        logger.info(f"Получено {len(result)} звонков")
        return result[:limit]

    async def get_call_recording_url(self, call_id: str) -> str:
        """URL записи разговора (если доступна и права позволяют).

        NB: REST не отдаёт прямую ссылку по CALL_ID; запись обычно лежит
        в RECORD_FILE_ID из статистики. Здесь возвращаем ID файла-записи
        как маркер наличия записи; скачивание — вне MCP (диск B24).
        """
        batch = await self._bitrix.call(
            self._METHOD_STATISTIC,
            {"FILTER": {"ID": call_id}, "START": 0},
        ) or []
        if batch:
            return batch[0].get("RECORD_FILE_ID", "")
        return ""
