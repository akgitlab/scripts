"""Доменная сущность: диалог (беседа) Bitrix24."""

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True, slots=True)
class Dialog:
    """Беседа/диалог Bitrix24 (im).

    :param dialog_id: ID диалога (в im API совпадает с chat_id для групп,
                      либо 'user{N}' для личных диалогов)
    :param title: Название беседы
    :param chat_type: Тип (P - личный, C - групповой, T - коллаб)
    :param user_count: Количество участников
    """

    dialog_id: str
    title: str = ""
    chat_type: str = "C"
    user_count: int = 0
    last_message: str = ""

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "Dialog":
        """Построение из ответа API."""
        return cls(
            dialog_id=str(data.get("ID") or data.get("chat_id") or ""),
            title=data.get("NAME") or data.get("TITLE") or "Личный диалог",
            chat_type=data.get("TYPE", "C"),
            user_count=int(data.get("USER_COUNT") or 0),
            last_message=data.get("LAST_MESSAGE") or "",
        )

    @classmethod
    def from_message_row(cls, row: dict[str, Any]) -> "Dialog":
        """Построение из строки im.dialog.messages.get."""
        return cls(
            dialog_id=str(row.get("CHAT_ID") or row.get("dialog_id") or ""),
            title=row.get("chat_title", ""),
            chat_type=row.get("chat_type", "C"),
            last_message=row.get("text", ""),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "dialog_id": self.dialog_id,
            "title": self.title,
            "chat_type": self.chat_type,
            "user_count": self.user_count,
            "last_message": self.last_message,
        }

    def to_str_json(self) -> str:
        import json
        return json.dumps(self.to_dict(), ensure_ascii=False)


@dataclass(frozen=True, slots=True)
class DialogMessage:
    """Реплика в диалоге."""

    message_id: int
    dialog_id: str
    author_id: int
    author_name: str
    text: str
    timestamp: str = ""

    @classmethod
    def from_api(cls, row: dict[str, Any], author_name: str = "") -> "DialogMessage":
        return cls(
            message_id=int(row.get("ID") or 0),
            dialog_id=str(row.get("CHAT_ID") or row.get("dialog_id") or ""),
            author_id=int(row.get("AUTHOR_ID") or 0),
            author_name=author_name,
            text=row.get("TEXT") or row.get("text") or "",
            timestamp=row.get("TIMESTAMP", ""),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "message_id": self.message_id,
            "dialog_id": self.dialog_id,
            "author_id": self.author_id,
            "author_name": self.author_name,
            "text": self.text,
            "timestamp": self.timestamp,
        }

    def to_str_json(self) -> str:
        import json
        return json.dumps(self.to_dict(), ensure_ascii=False)
