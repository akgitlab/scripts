"""Обработчики MCP для чатов (overlay)."""

from src.infrastructure.mcp.handlers.chat import register_chat_handlers

__all__ = ["register_chat_handlers"]
