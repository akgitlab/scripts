"""Презентационный слой MCP (overlay-версия).

Отличие от upstream: регистрируются также обработчики чатов и телефонии.
"""

from mcp.server.fastmcp import FastMCP

from src.infrastructure.mcp.handlers import (
    register_call_handlers,
    register_chat_handlers,
    register_contact_handlers,
    register_deal_handlers,
)
from src.infrastructure.mcp.server import BitrixMCPServer


def create_mcp_server() -> FastMCP:
    """Создание и настройка MCP сервера для Bitrix24.

    Регистрирует обработчики CRM, чатов и телефонии.

    :return: Настроенный экземпляр MCP сервера
    """
    mcp_server = BitrixMCPServer()
    register_contact_handlers(mcp_server)
    register_deal_handlers(mcp_server)
    register_chat_handlers(mcp_server)
    register_call_handlers(mcp_server)
    return mcp_server.server
