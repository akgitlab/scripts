"""Обработчики MCP: чаты и реплики диалогов Bitrix24."""

import json

from fast_bitrix24 import Bitrix

from src.application.services.dialog import DialogService
from src.infrastructure.bitrix.bitrix_dialog_repository import BitrixDialogRepository
from src.infrastructure.ioc import provider
from src.infrastructure.logging.logger import logger
from src.infrastructure.mcp.server import BitrixMCPServer

# Зависимости на уровне модуля — тот же паттерн, что в upstream-обработчиках
_webhook_url = provider.provide_bitrix_webhook_url()
dialog_service = DialogService(BitrixDialogRepository(Bitrix(_webhook_url)))


def register_chat_handlers(mcp_server: BitrixMCPServer) -> None:
    """Регистрация инструментов для работы с беседами."""
    mcp_server.add_tool(
        list_dialogs,
        name="list_dialogs",
        description=(
            "Список недавних диалогов/бесед Bitrix24, где состоит владелец вебхука. "
            "Возвращает dialog_id для последующего чтения истории."
        ),
    )
    mcp_server.add_tool(
        get_dialog_history,
        name="get_dialog_history",
        description=(
            "Получение реплик диалога (история сообщений) по dialog_id "
            "в хронологическом порядке."
        ),
    )
    mcp_server.add_tool(
        create_chat,
        name="create_chat",
        description=(
            "Создание групповой беседы Bitrix24 с участниками. "
            "user_ids — список ID пользователей."
        ),
    )
    mcp_server.add_tool(
        send_message,
        name="send_message",
        description="Отправка сообщения в беседу/диалог от имени владельца вебхука.",
    )
    mcp_server.add_tool(
        analyze_dialog,
        name="analyze_dialog",
        description=(
            "Агрегированная сводка по диалогу: объём, участники, "
            "кто сколько написал, первая/последняя реплика."
        ),
    )
    logger.info("Зарегистрированы обработчики чатов (im)")


async def list_dialogs(limit: int = 20) -> str:
    """Список недавних диалогов."""
    try:
        dialogs = await dialog_service.list_recent(limit)
        return json.dumps(
            {"total": len(dialogs), "dialogs": [d.to_dict() for d in dialogs]},
            ensure_ascii=False,
        )
    except Exception as e:  # noqa: BLE001
        return json.dumps({"error": str(e)}, ensure_ascii=False)


async def get_dialog_history(dialog_id: str, limit: int = 50) -> str:
    """История сообщений диалога."""
    try:
        messages = await dialog_service.history(dialog_id, limit)
        return json.dumps(
            {
                "dialog_id": dialog_id,
                "total": len(messages),
                "messages": [m.to_dict() for m in messages],
            },
            ensure_ascii=False,
        )
    except Exception as e:  # noqa: BLE001
        return json.dumps({"error": str(e)}, ensure_ascii=False)


async def create_chat(
    title: str,
    user_ids: list[int],
    description: str = "",
) -> str:
    """Создание беседы."""
    try:
        result = await dialog_service.create_chat(title, user_ids, description)
        return json.dumps({"success": True, "result": result}, ensure_ascii=False)
    except Exception as e:  # noqa: BLE001
        return json.dumps({"success": False, "error": str(e)}, ensure_ascii=False)


async def send_message(dialog_id: str, message: str) -> str:
    """Отправка сообщения."""
    try:
        result = await dialog_service.send(dialog_id, message)
        return json.dumps({"success": True, "result": result}, ensure_ascii=False)
    except Exception as e:  # noqa: BLE001
        return json.dumps({"success": False, "error": str(e)}, ensure_ascii=False)


async def analyze_dialog(dialog_id: str, limit: int = 100) -> str:
    """Сводка по диалогу для анализа."""
    try:
        return json.dumps(
            await dialog_service.analyze_dialog(dialog_id, limit), ensure_ascii=False,
        )
    except Exception as e:  # noqa: BLE001
        return json.dumps({"error": str(e)}, ensure_ascii=False)
