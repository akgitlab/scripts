"""Сервис: беседы и реплики Bitrix24."""

from src.domain.entities.dialog import Dialog, DialogMessage
from src.infrastructure.bitrix.bitrix_dialog_repository import BitrixDialogRepository
from src.infrastructure.logging.logger import logger


class DialogService:
    """Бизнес-логика поверх репозитория чатов."""

    def __init__(self, repository: BitrixDialogRepository) -> None:
        self._repository = repository

    async def list_recent(self, limit: int = 20) -> list[Dialog]:
        """Недавние диалоги/чаты владельца вебхука."""
        if limit < 1:
            raise ValueError("limit должен быть >= 1")
        return await self._repository.list_recent_dialogs(limit)

    async def history(self, dialog_id: str, limit: int = 50) -> list[DialogMessage]:
        """Реплики диалога в хронологическом порядке."""
        if not dialog_id:
            raise ValueError("dialog_id обязателен")
        return await self._repository.get_dialog_messages(dialog_id, limit)

    async def create_chat(
        self, title: str, user_ids: list[int], description: str = "",
    ) -> dict:
        """Создание беседы."""
        if not title.strip():
            raise ValueError("title обязателен")
        if not user_ids:
            raise ValueError("нужен хотя бы один участник")
        return await self._repository.create_chat(title, user_ids, description)

    async def send(self, dialog_id: str, text: str) -> dict:
        """Отправка сообщения в беседу."""
        return await self._repository.send_message(dialog_id, text)

    async def user_name(self, user_id: int) -> str:
        return await self._repository.get_user_name(user_id)

    async def analyze_dialog(self, dialog_id: str, limit: int = 100) -> dict:
        """Сводка по диалогу: участники, объём, авторы по вкладу.

        Удобный агрегат для ИИ-анализа бесед без выкачивания всего текста.
        """
        messages = await self.history(dialog_id, limit)
        if not messages:
            return {"dialog_id": dialog_id, "total": 0, "summary": "диалог пуст или недоступен"}

        authors: dict[int, int] = {}
        for m in messages:
            authors[m.author_id] = authors.get(m.author_id, 0) + 1

        return {
            "dialog_id": dialog_id,
            "total": len(messages),
            "first": messages[0].to_dict(),
            "last": messages[-1].to_dict(),
            "authors": [
                {"author_id": a, "messages": n}
                for a, n in sorted(authors.items(), key=lambda x: -x[1])
            ],
        }
