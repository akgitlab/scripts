"""Обработчики MCP: телефония Bitrix24."""

import json

from fast_bitrix24 import Bitrix

from src.application.services.call import CallService
from src.infrastructure.bitrix.bitrix_call_repository import BitrixCallRepository
from src.infrastructure.ioc import provider
from src.infrastructure.logging.logger import logger
from src.infrastructure.mcp.server import BitrixMCPServer

_webhook_url = provider.provide_bitrix_webhook_url()
call_service = CallService(BitrixCallRepository(Bitrix(_webhook_url)))


def register_call_handlers(mcp_server: BitrixMCPServer) -> None:
    """Регистрация инструментов телефонии."""
    mcp_server.add_tool(
        list_calls,
        name="list_calls",
        description=(
            "История звонков Bitrix24 (voximplant). Фильтры: user_id (оператор), "
            "call_type (1=исходящий, 2=входящий, 3/4=пропущенные), "
            "date_from/date_to (YYYY-MM-DD)."
        ),
    )
    mcp_server.add_tool(
        calls_summary,
        name="calls_summary",
        description=(
            "Агрегат по звонкам: входящие/исходящие/пропущенные, средняя "
            "длительность, сколько записей с записью разговора и связкой с CRM."
        ),
    )
    logger.info("Зарегистрированы обработчики телефонии (voximplant)")


async def list_calls(
    limit: int = 50,
    user_id: int | None = None,
    call_type: int | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
) -> str:
    """История звонков."""
    try:
        calls = await call_service.list_calls(limit, user_id, call_type, date_from, date_to)
        return json.dumps(
            {
                "total": len(calls),
                "calls": [
                    {**c.to_dict(), "call_type_raw": c.call_type} for c in calls
                ],
            },
            ensure_ascii=False,
        )
    except Exception as e:  # noqa: BLE001
        return json.dumps({"error": str(e)}, ensure_ascii=False)


async def calls_summary(limit: int = 200) -> str:
    """Агрегированная статистика звонков."""
    try:
        return json.dumps(
            await call_service.calls_summary(limit), ensure_ascii=False,
        )
    except Exception as e:  # noqa: BLE001
        return json.dumps({"error": str(e)}, ensure_ascii=False)
