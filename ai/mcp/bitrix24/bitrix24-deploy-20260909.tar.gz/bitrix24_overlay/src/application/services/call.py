"""Сервис: телефония Bitrix24."""

from collections import Counter

from src.domain.entities.call import Call
from src.infrastructure.bitrix.bitrix_call_repository import BitrixCallRepository
from src.infrastructure.logging.logger import logger


class CallService:
    """Бизнес-логика поверх репозитория звонков."""

    def __init__(self, repository: BitrixCallRepository) -> None:
        self._repository = repository

    async def list_calls(
        self,
        limit: int = 50,
        user_id: int | None = None,
        call_type: int | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
    ) -> list[Call]:
        if limit < 1:
            raise ValueError("limit должен быть >= 1")
        return await self._repository.list_calls(limit, user_id, call_type, date_from, date_to)

    async def calls_summary(self, limit: int = 200) -> dict:
        """Агрегат для анализа воронки: вход/исход/пропущенные, средняя длительность."""
        calls = await self._repository.list_calls(limit)
        if not calls:
            return {"total": 0}

        by_type = Counter(c.CALL_TYPES.get(c.call_type, str(c.call_type)) for c in calls)
        durations = [c.duration for c in calls if c.duration > 0]

        return {
            "total": len(calls),
            "by_type": dict(by_type),
            "avg_duration_sec": sum(durations) // len(durations) if durations else 0,
            "with_record": sum(1 for c in calls if c.record_url),
            "linked_to_crm": sum(1 for c in calls if c.crm_entity),
        }
