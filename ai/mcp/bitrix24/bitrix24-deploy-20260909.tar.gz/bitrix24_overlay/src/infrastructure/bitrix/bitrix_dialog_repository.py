"""Репозиторий: чаты и диалоги Bitrix24 (im)."""

from typing import Any, ClassVar

from fast_bitrix24 import Bitrix

from src.domain.entities.dialog import Dialog, DialogMessage
from src.infrastructure.logging.logger import logger


class BitrixDialogRepository:
    """Работа с беседами через REST im.* — от имени владельца вебхука.

    Видит только чаты, где владелец состоит (модель доступа im в B24).
    """

    _METHOD_RECENT: ClassVar[str] = "im.recent.get"
    _METHOD_DIALOG_MESSAGES: ClassVar[str] = "im.dialog.messages.get"
    _METHOD_CHAT_CREATE: ClassVar[str] = "im.chat.add"
    _METHOD_MESSAGE_SEND: ClassVar[str] = "im.message.add"
    _METHOD_USER_GET: ClassVar[str] = "im.user.get"
    _METHOD_CHAT_GET: ClassVar[str] = "im.chat.get"

    def __init__(self, bitrix: Bitrix) -> None:
        self._bitrix = bitrix

    async def list_recent_dialogs(self, limit: int = 20) -> list[Dialog]:
        """Список недавних диалогов/чатов владельца вебхука."""
        raw: dict[str, Any] = await self._bitrix.call(self._METHOD_RECENT) or {}
        items = list(raw.values()) if isinstance(raw, dict) else list(raw)
        dialogs = [Dialog.from_api(x) for x in items[:limit] if isinstance(x, dict)]
        logger.info(f"Получено {len(dialogs)} недавних диалогов")
        return dialogs

    async def get_chat_info(self, chat_id: int) -> dict[str, Any] | None:
        """Информация о конкретном чате."""
        raw = await self._bitrix.call(self._METHOD_CHAT_GET, {"CHAT_ID": chat_id})
        if isinstance(raw, dict) and raw:
            return next(iter(raw.values())) if len(raw) > 1 else raw
        return None

    async def get_dialog_messages(
        self,
        dialog_id: str,
        limit: int = 50,
    ) -> list[DialogMessage]:
        """Реплики диалога (хронологический порядок).

        :param dialog_id: chat_id (числовой) или 'user{N}' для личного диалога
        :param limit: Максимум реплик за запрос (API отдаёт постранично по 50)
        """
        result: list[DialogMessage] = []
        last_id: int | None = None

        while len(result) < limit:
            params: dict[str, Any] = {"DIALOG_ID": dialog_id, "LIMIT": 50}
            if last_id is not None:
                params["LAST_ID"] = last_id

            raw: dict[str, Any] = await self._bitrix.call(
                self._METHOD_DIALOG_MESSAGES, params,
            ) or {}

            messages = raw.get("messages", [])
            if not messages:
                break

            users = {u.get("id"): u for u in (raw.get("users") or [])
                     if isinstance(u, dict)}

            for m in messages:
                author = users.get(m.get("AUTHOR_ID"), {})
                result.append(DialogMessage.from_api(
                    m, author_name=author.get("name", ""),
                ))

            if len(messages) < 50:
                break
            last_id = min(int(m.get("ID", 0)) for m in messages)

        return result[:limit]

    async def create_chat(
        self,
        title: str,
        user_ids: list[int],
        description: str = "",
    ) -> dict[str, Any]:
        """Создание групповой беседы с участниками.

        :param title: Название беседы
        :param user_ids: Список ID пользователей-участников
        :param description: Описание (опционально)
        :return: {"chat_id": N} от API
        """
        if not user_ids:
            raise ValueError("user_ids не может быть пустым")

        params: dict[str, Any] = {
            "TYPE": "CHAT",
            "TITLE": title,
            "USERS": [str(u) for u in user_ids],
        }
        if description:
            params["DESCRIPTION"] = description

        result = await self._bitrix.call(self._METHOD_CHAT_CREATE, params)
        logger.info(f"Создан чат '{title}' (участников: {len(user_ids)}): {result}")
        return result

    async def send_message(self, dialog_id: str, text: str) -> dict[str, Any]:
        """Отправка сообщения в диалог/чат от имени владельца вебхука."""
        if not text.strip():
            raise ValueError("Пустое сообщение")

        result = await self._bitrix.call(
            self._METHOD_MESSAGE_SEND,
            {"DIALOG_ID": dialog_id, "MESSAGE": text},
        )
        logger.info(f"Сообщение в диалог {dialog_id} отправлено: {result}")
        return result

    async def get_user_name(self, user_id: int) -> str:
        """Имя пользователя (для авторов реплик)."""
        raw = await self._bitrix.call(self._METHOD_USER_GET, {"ID": user_id})
        if isinstance(raw, dict):
            parts = [raw.get("NAME", ""), raw.get("LAST_NAME", "")]
            return " ".join(p for p in parts if p).strip() or f"User {user_id}"
        return f"User {user_id}"
