#!/usr/bin/env bash
# Проверка прав вебхука Bitrix24, от которого работает MCP-сервер.
# Права MCP == права вебхука (сервер наследует их полностью).
# Фактические тесты — ТОЛЬКО read-only методы (никаких *.add/*.update/*.delete).
# Использование: mcp-bitrix24-perms-check.sh [путь_к_secrets.env]
set -u
SECRETS="${1:-/opt/mcp/servers/bitrix24/secrets/secrets.env}"
PASS=0; FAIL=0
ok()  { echo "  ✅ $1"; PASS=$((PASS+1)); }
bad() { echo "  ❌ $1"; FAIL=$((FAIL+1)); }
note() { echo "  ℹ️  $1"; }

b24() { # $1 = метод, $2 = JSON (опц.) -> stdout
    curl -sS -m 10 -X POST "${WH}${1}" -H 'Content-Type: application/json' \
        -d "${2:-{}}" 2>&1
}
count_result() { # читает "result" как массив, выводит кол-во элементов
    python3 -c "
import sys, json
try:
    d = json.load(sys.stdin)
    r = d.get('result')
    print(len(r) if isinstance(r, list) else 1)
except Exception:
    print(-1)
"
}

echo "=== Bitrix24 webhook permissions check ==="

# --- 0. Читаем вебхук ---
if [[ -r "$SECRETS" ]]; then
    WH=$(grep -m1 '^BITRIX_WEBHOOK_URL=' "$SECRETS" | cut -d= -f2-)
else
    echo "❌ secrets не читаются: $SECRETS"; exit 1
fi
[[ -n "$WH" ]] || { echo "❌ BITRIX_WEBHOOK_URL не найден"; exit 1; }
echo "Webhook host: $(echo "$WH" | grep -oE 'https://[^/]+')"

# --- 1. От чьего имени действует вебхук ---
echo
echo "[1/3] profile (владелец вебхука)"
PROFILE=$(b24 profile)
UID_=$(echo "$PROFILE" | grep -oE '"ID":"?[0-9]+"?' | head -1 | cut -d: -f2 | tr -d '"')
NAME=$(echo "$PROFILE" | grep -oE '"NAME":"[^"]*"' | head -1 | cut -d: -f2-)
if [[ -n "$UID_" ]] && echo "$PROFILE" | grep -q '"result"'; then
    ok "вебхук действует как: ${NAME//\"/} (ID=$UID_)"
    note "к данным применяются права этого пользователя, не только scope"
    if echo "$PROFILE" | grep -q '"ADMIN":true'; then
        note "владелец — АДМИН портала: доступ ко всем данным CRM"
    fi
else
    bad "profile недоступен: $(echo "$PROFILE" | head -c 150)"
fi

# --- 2. scope вебхука: required/optional ---
echo
echo "[2/3] scope (права, выданные при создании вебхука)"
SCOPES=$(b24 scope)
if ! echo "$SCOPES" | grep -q '"result"'; then
    bad "scope недоступен: $(echo "$SCOPES" | head -c 150)"
    SCOPES='{"result":[]}'
fi
have() { echo "$SCOPES" | grep -qE "\"$1\""; }

SCOPE_DESC="crm:контакты/сделки/лиды|im:чаты и сообщения|imbot:боты в чатах|telephony:телефония|user:пользователи/структура|department:отделы|lists:списки|disk:диск|calendar:календарь|tasks_extended:задачи"

echo "$SCOPES" | python3 -c "
import sys, json
desc = '$SCOPE_DESC'.split('|')
d = {k: v for k, v in (x.split(':') for x in desc if ':' in x)}
for s in sorted(json.load(sys.stdin)['result']):
    print(f'  - {s:20s} {d.get(s, \"\")}')"

# REQUIRED под задачи: CRM-воронка + беседы + звонки
for S in crm im telephony; do
    if have "$S"; then
        ok "scope '$S' есть (required)"
    else
        bad "scope '$S' ОТСУТСТВУЕТ (required для: crm=воронка, im=беседы, telephony=звонки)"
    fi
done
# OPTIONAL
for S in user department imbot; do
    if have "$S"; then
        ok "scope '$S' есть (optional)"
    else
        note "scope '$S' не выдан (optional: user/department=аналитика по менеджерам, imbot=живой бот с событиями)"
    fi
done

# --- 3. Фактические read-only тесты по областям ---
echo
echo "[3/3] фактические вызовы (read-only)"

# crm
if have crm; then
    R=$(b24 crm.deal.list '{"select":["ID","TITLE"],"params":{"start":-1}}')
    T=$(echo "$R" | grep -oE '"total":[0-9]+' | cut -d: -f2)
    if echo "$R" | grep -q '"result"'; then
        ok "crm.deal.list ok (total=${T:-?})"
    else
        bad "crm.deal.list: $(echo "$R" | head -c 120)"
    fi
else
    bad "crm: тест пропущен (нет scope)"
fi

# im: список недавних диалогов/чатов
if have im; then
    R=$(b24 im.recent.get)
    if echo "$R" | grep -q '"result"'; then
        N=$(echo "$R" | count_result)
        ok "im.recent.get ok ($N недавних диалогов/чатов)"
        note "им scope видит только чаты, где владелец вебхука состоит или создал их"
    else
        bad "im.recent.get: $(echo "$R" | head -c 120)"
    fi
else
    bad "im: тест пропущен (нет scope)"
fi

# telephony: история звонков
if have telephony; then
    R=$(b24 voximplant.statistic.get '{"FILTER":{},"START":0}')
    if echo "$R" | grep -q '"result"'; then
        N=$(echo "$R" | count_result)
        ok "voximplant.statistic.get ok ($N записей в выборке)"
    else
        bad "voximplant.statistic.get: $(echo "$R" | head -c 120)"
    fi
else
    bad "telephony: тест пропущен (нет scope)"
fi

# user
if have user; then
    R=$(b24 user.get "{}")
    if echo "$R" | grep -q '"result"'; then
        N=$(echo "$R" | count_result)
        ok "user.get ok ($N пользователей в выборке)"
    else
        bad "user.get: $(echo "$R" | head -c 120)"
    fi
fi

# department
if have department; then
    R=$(b24 department.get "{}")
    if echo "$R" | grep -q '"result"'; then
        N=$(echo "$R" | count_result)
        ok "department.get ok ($N отделов в выборке)"
    else
        bad "department.get: $(echo "$R" | head -c 120)"
    fi
fi

echo
echo "=== ИТОГ: $PASS passed, $FAIL failed ==="
exit $FAIL
